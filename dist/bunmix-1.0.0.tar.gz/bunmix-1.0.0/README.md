# Welcome to Bunmix
Bayesian unmixing of remanence curves